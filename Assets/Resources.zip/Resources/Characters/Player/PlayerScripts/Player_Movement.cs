using UnityEngine;

public class Player_Movement : MonoBehaviour
{

    [Header("Components")]
    public Rigidbody2D body;
    public BoxCollider2D groundCheck;
    public LayerMask groundMask;
    public Animator animator;



    [Header("Físiques")]
    public float acceleration;
    [Range(0f, 1f)]
    public float groundDecay;



    [Header("Jump i Falling")]
    public float jumpForce;
    public float slowMoSalt;
    public float fallMultiplier;
    public float maxFallSpeed;
    public float lastGroundTime; //Si el jugador és a terra i ha clicat el salt fa poc (mentre estaba al aire) saltarà automaticament
    public float lastJumpTime; //Guarda el temps de l'ultim input de salt
    public float jumpCoyoteTime; //0.2f es el temps que el jugador podrà saltar després de caure si no ha saltat abans, pq el joc se senti responsive


    [Header("Velocitats")]
    public float maxXSpeed;




    [Header("Bools")]
    public bool isGrounded;
    public bool isGrabbingLedge; //Per si el jugador s'agafa just a la punta d'una paret


    [Header("Ledge Grabing")]
    [SerializeField] Vector2 ledgeGrabingOffset;



    [Header("Inpunts")]
    float xInput;
    float yInput;
    bool jumpPressed;
    

    void Update(){
        CheckInput();
    }

    void FixedUpdate(){
        CheckGround();
        HandleLedgeGrabbing();
        
        if (!isGrabbingLedge) {
            Moviment_Horitzontal();
            HandleFall();
            HandleJumpBuffer();
            HandleJump();
            Aplicar_Friccio();
            HandleSlowMoJump();
        }
        
        UpdateAnimations();
    }

    void CheckInput(){
        xInput = Input.GetAxis("Horizontal");
        yInput = Input.GetAxis("Vertical");

        if (Input.GetButtonDown("Jump")){
            jumpPressed = true;
            lastJumpTime = Time.time;
        }
    }

    void HandleLedgeGrabbing() {
        if (isGrabbingLedge) {
            body.linearVelocity = Vector2.zero;
            
            if (jumpPressed) {
                ReleaseLedge();

                if (Mathf.Abs(xInput) > 0) {
                    body.linearVelocity = new Vector2(xInput * maxXSpeed, jumpForce);
                } 
                else {
                    body.linearVelocity = new Vector2(0, jumpForce);
                }
                
                jumpPressed = false;
            }
        }
    }

    void Moviment_Horitzontal(){
        if (Mathf.Abs(xInput) > 0){
            float increment = xInput * acceleration;
            float newSpeed = Mathf.Clamp(body.linearVelocity.x + increment, -maxXSpeed, maxXSpeed);
            body.linearVelocity = new Vector2(xInput * maxXSpeed, body.linearVelocity.y);

            Canvi_Direccio_Canvas();
        }
    }

    void Canvi_Direccio_Canvas(){
        float direction = Mathf.Sign(xInput);
        transform.localScale = new Vector3(direction, 1, 1);
    }

    void HandleJump(){
        if (jumpPressed && isGrounded){
            //Si salta en moviment
            if (body.linearVelocity.x > 0 || body.linearVelocity.x < 0 || Time.time - lastGroundTime <= jumpCoyoteTime){
                body.linearVelocity = new Vector2(body.linearVelocity.x, jumpForce);
            }
            //Reiniciem la bandera de salt
            jumpPressed = false;
        }
    }

    void HandleFall(){
        //En el seu punt màxim de la Y (salt) - Si està caient, aplicar una gravetat extra i limitar la velocitat de caiguda
        if (body.linearVelocity.y < 0){
            body.linearVelocity += Vector2.down * fallMultiplier * Time.deltaTime;
            body.linearVelocity = new Vector2(body.linearVelocity.x, Mathf.Max(body.linearVelocity.y, -maxFallSpeed));
        }
    }

    void HandleSlowMoJump(){
        if (!isGrounded && Mathf.Abs(body.linearVelocity.y) < 0.1f && Mathf.Abs(body.linearVelocity.y) > 0.1f){
            body.gravityScale = slowMoSalt;
        }
        else{
            body.gravityScale = 1f;
        }
    }

    void HandleJumpBuffer(){
        if (isGrounded && lastJumpTime > 0 && Time.time - lastJumpTime <= lastGroundTime){
            body.linearVelocity = new Vector2(body.linearVelocity.x, jumpForce);
            lastJumpTime = -1f;
        }
    }

    void CheckGround(){
        isGrounded = Physics2D.OverlapAreaAll(groundCheck.bounds.min, groundCheck.bounds.max, groundMask).Length > 0;
    }


    void Aplicar_Friccio(){
        if (isGrounded && xInput == 0 && body.linearVelocity.y <= 0){
            body.linearVelocity *= groundDecay;
        }
    }

    public void GrabLedge(Vector2 ledgePosition, bool changePosition = true){
        isGrabbingLedge = true;
        body.linearVelocity = Vector2.zero;
        body.gravityScale = 0;

        if (changePosition){
            transform.position = new Vector2(ledgePosition.x, ledgePosition.y - ledgeGrabingOffset.y);
        }
    }

    public void ReleaseLedge(){
        isGrabbingLedge = false;
        body.gravityScale = 1;
    }

    void UpdateAnimations(){
        animator.SetBool("isRunning", Mathf.Abs(xInput) > 0 && isGrounded);
        animator.SetBool("isJumping", !isGrounded && body.linearVelocity.y > 0);
        animator.SetBool("isFalling", !isGrounded && body.linearVelocity.y < 0);
        animator.SetBool("isGrabbingLedge", isGrabbingLedge);
    }
}